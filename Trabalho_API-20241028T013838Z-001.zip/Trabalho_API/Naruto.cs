﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace naruto
{
    public class Naruto
    {

        public int Id { get; set; }
        public string Name { get; set; }
        private string[] Images { get; set; }

        public string[] Jutsu { get; set; }

       


        public Naruto(int id)
        {
            Id = id;

            string json = GetJsonFromApi(id);
            var jsonObject = JObject.Parse(json);

            Name = jsonObject["name"].ToString();
          
            Images = jsonObject["images"].ToObject<string[]>();
           
            Jutsu = jsonObject["jutsu"].ToObject<string[]>();
           

        }

        private string GetJsonFromApi(int Id)
        {
            string url = $"https://dattebayo-api.onrender.com/characters/{Id}";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(url).Result; // Bloqueia até que a tarefa seja concluída
                response.EnsureSuccessStatusCode(); // Lança uma exceção se o status não for 200-299

                return response.Content.ReadAsStringAsync().Result; // Lê o conteúdo da resposta
            }
        }

        public Image GetRandomImage()
        {
            Random rnd = new Random();
            int numero = rnd.Next(Images.Length);
            string url = Images[numero];

            using (HttpClient client = new HttpClient())
            {
                // Faz a requisição GET para a URL da imagem
                var response = client.GetAsync(url).Result; // Bloqueante
                response.EnsureSuccessStatusCode(); // Lança exceção se a resposta não for bem-sucedida

                // Lê o conteúdo da resposta como um array de bytes
                var imageBytes = response.Content.ReadAsByteArrayAsync().Result; // Bloqueante

                // Converte o array de bytes em um objeto Image
                using (var ms = new MemoryStream(imageBytes))
                {
                    return Image.FromStream(ms);
                }
            }
        }
    }


    public class aldeia
    {
        public int Id { get; set; }
        public string Name { get; set; }
        private string[] Imagem { get; set; }

        public aldeia(int id)

        {
            Id = id;


            string json = GetJsonFromApi(id);
            var jsonObject = JObject.Parse(json);

            Name = jsonObject["name"].ToString();
            // Imagem = jsonObject["imagem"].ToObject<string[]>();
        }

        private string GetJsonFromApi(int Id)
        {
            string url = $"https://dattebayo-api.onrender.com/villages/{Id}";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(url).Result; // Bloqueia até que a tarefa seja concluída
                response.EnsureSuccessStatusCode(); // Lança uma exceção se o status não for 200-299

                return response.Content.ReadAsStringAsync().Result; // Lê o conteúdo da resposta
            }
        }

        public Image GetRandomImage()
        {
            Random rnd = new Random();
            int numero = rnd.Next(Imagem.Length);
            string url = Imagem[numero];

            using (HttpClient client = new HttpClient())
            {
                // Faz a requisição GET para a URL da imagem
                var response = client.GetAsync(url).Result; // Bloqueante
                response.EnsureSuccessStatusCode(); // Lança exceção se a resposta não for bem-sucedida

                // Lê o conteúdo da resposta como um array de bytes
                var imageBytes = response.Content.ReadAsByteArrayAsync().Result; // Bloqueante

                // Converte o array de bytes em um objeto Image
                using (var ms = new MemoryStream(imageBytes))
                {
                    return Image.FromStream(ms);
                }
            }
        }

    }


        public class equipe
        {
            public int Id { get; set; }
            public string Name { get; set; }


        public equipe(int id)

        {
            Id = id;


            string json = GetJsonFromApi(id);
            var jsonObject = JObject.Parse(json);

            Name = jsonObject["name"].ToString();
            
        }

        private string GetJsonFromApi(int Id)
        {
            string url = $"https://dattebayo-api.onrender.com/teams/{Id}";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(url).Result; // Bloqueia até que a tarefa seja concluída
                response.EnsureSuccessStatusCode(); // Lança uma exceção se o status não for 200-299

                return response.Content.ReadAsStringAsync().Result; // Lê o conteúdo da resposta
            }
        }



    }

    public class grupo
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public grupo(int id) 
        
        {
            Id = id;


            string json = GetJsonFromApi(id);
            var jsonObject = JObject.Parse(json);

            Name = jsonObject["name"].ToString();
        }

        private string GetJsonFromApi(int Id)
        {
            string url = $"https://dattebayo-api.onrender.com/clans/{Id}";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(url).Result; // Bloqueia até que a tarefa seja concluída
                response.EnsureSuccessStatusCode(); // Lança uma exceção se o status não for 200-299

                return response.Content.ReadAsStringAsync().Result; // Lê o conteúdo da resposta
            }
        }
    }

    public class a_k
    {
        public int Id { get; set; }
        public string Name { get; set; }


        public a_k(int id) 
        {
            Id = id;


            string json = GetJsonFromApi(id);
            var jsonObject = JObject.Parse(json);

            Name = jsonObject["name"].ToString();
        }

        private string GetJsonFromApi(int Id)
        {
            string url = $"https://dattebayo-api.onrender.com/akatsuki/{Id}";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(url).Result; // Bloqueia até que a tarefa seja concluída
                response.EnsureSuccessStatusCode(); // Lança uma exceção se o status não for 200-299

                return response.Content.ReadAsStringAsync().Result; // Lê o conteúdo da resposta
            }
        }

    }


    public class bestas 
    {
        public int Id { get; set; }
        public string Name { get; set; }
        private string[] Images { get; set; }

        public string[] NatureType { get; set; }

        public string[] Jutsu { get; set; }


        public bestas(int id)
        {
            Id = id;

            string json = GetJsonFromApi(id);
            var jsonObject = JObject.Parse(json);

            Name = jsonObject["name"].ToString();           
            Images = jsonObject["images"].ToObject<string[]>();
            NatureType = jsonObject["natureType"].ToObject<string[]>();
            Jutsu = jsonObject["jutsu"].ToObject<string[]>();


        }


        private string GetJsonFromApi(int Id)
        {
            string url = $"https://dattebayo-api.onrender.com/tailed-beasts/{Id}";
            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage response = client.GetAsync(url).Result; // Bloqueia até que a tarefa seja concluída
                response.EnsureSuccessStatusCode(); // Lança uma exceção se o status não for 200-299

                return response.Content.ReadAsStringAsync().Result; // Lê o conteúdo da resposta
            }
        }

        public Image GetRandomImage()
        {
            Random rnd = new Random();
            int numero = rnd.Next(Images.Length);
            string url = Images[numero];

            using (HttpClient client = new HttpClient())
            {
                // Faz a requisição GET para a URL da imagem
                var response = client.GetAsync(url).Result; // Bloqueante
                response.EnsureSuccessStatusCode(); // Lança exceção se a resposta não for bem-sucedida

                // Lê o conteúdo da resposta como um array de bytes
                var imageBytes = response.Content.ReadAsByteArrayAsync().Result; // Bloqueante

                // Converte o array de bytes em um objeto Image
                using (var ms = new MemoryStream(imageBytes))
                {
                    return Image.FromStream(ms);
                }
            }
        }
    }

}

