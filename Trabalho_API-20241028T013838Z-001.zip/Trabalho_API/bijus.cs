﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace naruto
{
    public partial class bijus : Form
    {
        public bijus()
        {
            InitializeComponent();
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int id = (int)numericUpDown1.Value;

            try
            {
                // Cria o personagem de acordo com o id, trazendo as informações da API
                bestas bestas = new bestas(id);

                textBox1.Text = bestas.Name;
                pictureBox2.Image = bestas.GetRandomImage();
                listBox1.DataSource = bestas.NatureType;
                listBox2.DataSource = bestas.Jutsu;
           
                

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao obter dados: {ex.Message}");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }
    }
}
