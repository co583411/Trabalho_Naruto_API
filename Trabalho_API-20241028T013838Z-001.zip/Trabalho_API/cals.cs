﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace naruto
{
    public partial class cals : Form
    {
        public cals()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

            int id = (int)numericUpDown1.Value;

            try
            {
                // Cria o personagem de acordo com o id, trazendo as informações da API
                int numero = (id);
                if (numero >= 0 && numero <= 19)
                { 
                    grupo grupo = new grupo(id);


                //pictureBox2.Image = aldeia.GetRandomImage();
                textBox1.Text = grupo.Name;
                pictureBox2.Image = imageList1.Images[id];
            }
                else
            {
                MessageBox.Show("acabou volte para o 19");
            }

        }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao obter dados: {ex.Message}");
            }
        }
    }
}
