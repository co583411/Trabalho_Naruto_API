﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace naruto
{
    public partial class personagens : Form
    {
        public personagens()
        {
            InitializeComponent();
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        public void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            int id = (int)numericUpDown1.Value;


            try
            {
                // Cria o personagem de acordo com o id, trazendo as informações da API
                Naruto naruto = new Naruto(id);

                textBox1.Text = naruto.Name;
                pictureBox2.Image = naruto.GetRandomImage();
               
                listBox2.DataSource = naruto.Jutsu;
            

            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao obter dados: {ex.Message}");
            }
        }

        private Naruto Naruto(int id)
        {
            throw new NotImplementedException();
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
