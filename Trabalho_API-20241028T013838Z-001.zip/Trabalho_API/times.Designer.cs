﻿namespace naruto
{
    partial class times
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(times));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-6, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(877, 450);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(717, 49);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(120, 20);
            this.numericUpDown1.TabIndex = 3;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(355, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(189, 20);
            this.textBox1.TabIndex = 4;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(295, 63);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(306, 356);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "0.jpg");
            this.imageList1.Images.SetKeyName(1, "1.jpg");
            this.imageList1.Images.SetKeyName(2, "4 (1).jpg");
            this.imageList1.Images.SetKeyName(3, "5.jpg");
            this.imageList1.Images.SetKeyName(4, "6.jpg");
            this.imageList1.Images.SetKeyName(5, "8 (1).png");
            this.imageList1.Images.SetKeyName(6, "9.1.png");
            this.imageList1.Images.SetKeyName(7, "19.jpg");
            this.imageList1.Images.SetKeyName(8, "20.PNG.jpg");
            this.imageList1.Images.SetKeyName(9, "21.jpg");
            this.imageList1.Images.SetKeyName(10, "10.jpg");
            this.imageList1.Images.SetKeyName(11, "11 (2).jpg");
            this.imageList1.Images.SetKeyName(12, "12.3.jpg");
            this.imageList1.Images.SetKeyName(13, "13.3PNG.jpg");
            this.imageList1.Images.SetKeyName(14, "14 (2).jpg");
            this.imageList1.Images.SetKeyName(15, "15.jpg");
            this.imageList1.Images.SetKeyName(16, "16.PNG.jpg");
            this.imageList1.Images.SetKeyName(17, "17.jpg");
            this.imageList1.Images.SetKeyName(18, "18 (1).jpg");
            this.imageList1.Images.SetKeyName(19, "14 (2).jpg");
            this.imageList1.Images.SetKeyName(20, "13.3PNG.jpg");
            this.imageList1.Images.SetKeyName(21, "12.3.jpg");
            this.imageList1.Images.SetKeyName(22, "11 (2).jpg");
            this.imageList1.Images.SetKeyName(23, "21.jpg");
            this.imageList1.Images.SetKeyName(24, "20.PNG.jpg");
            this.imageList1.Images.SetKeyName(25, "19 (1).jpg");
            this.imageList1.Images.SetKeyName(26, "19.jpg");
            this.imageList1.Images.SetKeyName(27, "4 (1).jpg");
            this.imageList1.Images.SetKeyName(28, "1 (1).jpg");
            this.imageList1.Images.SetKeyName(29, "1.jpg");
            this.imageList1.Images.SetKeyName(30, "0.jpg");
            this.imageList1.Images.SetKeyName(31, "17.jpg");
            this.imageList1.Images.SetKeyName(32, "16.PNG (1).jpg");
            this.imageList1.Images.SetKeyName(33, "16.PNG.jpg");
            this.imageList1.Images.SetKeyName(34, "15.jpg");
            this.imageList1.Images.SetKeyName(35, "14.2.jpg");
            this.imageList1.Images.SetKeyName(36, "13.PNG.jpg");
            this.imageList1.Images.SetKeyName(37, "12 (2).jpg");
            this.imageList1.Images.SetKeyName(38, "12 (1).jpg");
            this.imageList1.Images.SetKeyName(39, "12.jpg");
            this.imageList1.Images.SetKeyName(40, "14 (1).jpg");
            this.imageList1.Images.SetKeyName(41, "11 (1).jpg");
            this.imageList1.Images.SetKeyName(42, "11.jpg");
            this.imageList1.Images.SetKeyName(43, "9.3 (2).jpg");
            this.imageList1.Images.SetKeyName(44, "9.3 (1).jpg");
            this.imageList1.Images.SetKeyName(45, "9.3.jpg");
            this.imageList1.Images.SetKeyName(46, "8s.jpg");
            this.imageList1.Images.SetKeyName(47, "19.2.jpg");
            this.imageList1.Images.SetKeyName(48, "15.1 (1).jpg");
            this.imageList1.Images.SetKeyName(49, "18.jpg");
            this.imageList1.Images.SetKeyName(50, "15.1.jpg");
            this.imageList1.Images.SetKeyName(51, "14.jpg");
            this.imageList1.Images.SetKeyName(52, "9.2.jpg");
            this.imageList1.Images.SetKeyName(53, "8.jpg");
            this.imageList1.Images.SetKeyName(54, "19.19.jpg");
            // 
            // times
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 450);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "times";
            this.Text = "times";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ImageList imageList1;
    }
}